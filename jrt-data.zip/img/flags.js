flag_[000000] = "Enter the flag image name here";
