liste_sessions = [];
last_sessionid = 0;
last_sessionnum = 0;
