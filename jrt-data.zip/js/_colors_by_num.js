//col_by_num['012'] = '#ff8800';
//bg_by_num['012'] = '#8800ff';
