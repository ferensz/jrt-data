trackmap_disp_mode = 3
transparence_fond_trackmap = 0.9
trackmap_color = '#ffffff'
trackmap_bg_color = '#000000'

broadcast=2
fps_broadcast=2.0